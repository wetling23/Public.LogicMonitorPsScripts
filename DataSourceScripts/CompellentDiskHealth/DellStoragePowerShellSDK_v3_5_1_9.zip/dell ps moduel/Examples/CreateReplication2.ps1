﻿ #******************************************************************************
 #*              Copyright 2014-2017 Dell Inc. or its subsidiaries.
 #*                           ALL RIGHTS RESERVED
 #*
 #*   THIS DOCUMENT OR ANY PART OF THIS DOCUMENT MAY NOT BE REPRODUCED WITHOUT
 #*   WRITTEN PERMISSION FROM DELL INC.
 #*
 #*   THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE RISK
 #*   OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
 #*
 #*   THIS CODE IS FOR DEMONSTRATION ONLY AND SHOULD NOT BE USED IN PRODUCTION ENVIRONMENTS 
 #*
 #******************************************************************************
# Script to create Replication more concisely than CreateReplication.ps1
#
param
(
	[string] $scSource = $(Read-Host -prompt "scSourceSerialNumber"),
	[string] $scDest = $(Read-Host -prompt "scDestSerialNumber"),
	[bool] $cleanup = $TRUE,
    [string] $username = $(Read-Host -prompt "Data Collector Username"),
    [string] $password = $(Read-Host -prompt "Data Collector Password"),
    [string] $hostname = $(Read-Host -prompt "Data Collector Hostname"),
    [string] $port = $(Read-Host -prompt "Data Collector Port")
)

# Get the Connection to the Data Collector
$pass = ConvertTo-SecureString $password -AsPlainText -Force
$conn = Connect-DellApiConnection -Host $hostname -Port $port -User $username -password $pass
if($conn -eq $null)
{
    Write-Host "Error Connecting to the Data Collector" -ForegroundColor Red
    break
}

. .\ApiFunctions.ps1

if (!$?)
{
	Write-Host "Error Loading Api Functions File" -ForegroundColor Red
	break
}

Write-Host "Start Create Replication Example [Source SN: $scSource]  [Dest SN: $scDest]"  -ForegroundColor Green

# Gets the QoS Node
$qosList = Get-DellScReplicationQosNode -StorageCenter (Get-DellStorageCenter -SerialNumber $scSource)
if($qosList -eq $null -or  $qosList.Count -eq 0)
{
	Write-Host "No QoS Nodes Found on Storage Center" -ForegroundColor Red
	break
}

if($qosList.Count -eq 1)
{
	$qos = $qosList
}
else
{
	$qos = $qosList[0]
}

# Create a new Replication
Write-Host "Create the Replication [QoS: $qos]" -ForegroundColor Green
$replication = New-DellScReplication -StorageCenter (Get-DellStorageCenter -SerialNumber $scSource) `
								-DestStorageCenter (Get-DellStorageCenter -SerialNumber $scDest) `
								-SourceVolume (New-DellScVolume -StorageCenter (Get-DellStorageCenter -SerialNumber $scSource) `
								-Name (GetNextVolumeName $source "CreateReplication2ViaPs") -Size 25Gb) -QosNode $qos
if($replication -eq $null)
{
	Write-Host "Error Creating Replication on source Storage Center" -ForegroundColor Red
	break
}

if(!$cleanup)
{
	break
}

# 
# Now Cleanup all the things created in the Example
#
$preferenceLevel = $confirmPreference
$confirmPreference = "None"

Write-Host "Abort the Replication [Name: $replication]" -ForegroundColor Green
Remove-DellScReplication -instance $replication
Write-Host "Delete the Source Volume" -ForegroundColor Green
Remove-DellScVolume -instance (Get-DellScVolume -instanceid $replication.SourceVolume.InstanceId)
Write-Host "Delete the Destination Volume" -ForegroundColor Green
Remove-DellScVolume -instance (Get-DellScVolume -instanceid $replication.DestVolume.InstanceId)

$confirmPreference = $preferenceLevel

