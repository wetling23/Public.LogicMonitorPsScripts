﻿ #******************************************************************************
 #*              Copyright 2014-2017 Dell Inc. or its subsidiaries.
 #*                           ALL RIGHTS RESERVED
 #*
 #*   THIS DOCUMENT OR ANY PART OF THIS DOCUMENT MAY NOT BE REPRODUCED WITHOUT
 #*   WRITTEN PERMISSION FROM DELL INC.
 #*
 #*   THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE RISK
 #*   OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
 #*
 #*   THIS CODE IS FOR DEMONSTRATION ONLY AND SHOULD NOT BE USED IN PRODUCTION ENVIRONMENTS 
 #*
 #******************************************************************************
#
# Script to map a Volume to a Server
#
param
(
	[string] $scSn = $(Read-Host -prompt "StorageCenterSerialNumber"),
	[string] $serverName = $(Read-Host -prompt "ServerName"),
    [string] $username = $(Read-Host -prompt "Data Collector Username"),
    [string] $password = $(Read-Host -prompt "Data Collector Password"),
    [string] $hostname = $(Read-Host -prompt "Data Collector Hostname"),
    [string] $port = $(Read-Host -prompt "Data Collector Port")
)

# Get the Connection to the Data Collector
$pass = ConvertTo-SecureString $password -AsPlainText -Force
$conn = Connect-DellApiConnection -Host $hostname -Port $port -User $username -password $pass
if($conn -eq $null)
{
    Write-Host "Error Connecting to the Data Collector" -ForegroundColor Red
    break
}

. .\ApiFunctions.ps1
if (!$?)
{
	Write-Host "Error Loading API Functions File" -ForegroundColor Red
	break
}
Write-Host "Start Map Volume Example [StorageCenter: $scSn]  [ServerName: $serverName]"  -ForegroundColor Green

$sc = Get-DellStorageCenter -Connection $conn -SerialNumber $scSn

if($sc -eq $null)
{
	Write-Host "Error Connecting to the Storage Center" -ForegroundColor Red
	break
}

Write-Host "Storage Center: $sc" -ForegroundColor Green

# Get a unique Volume Name
$volumeName = GetNextVolumeName $sc $conn "MapVolume"

# Create a new Volume
Write-Host "Create new Volume on the StorageCenter [Name: $volumeName]" -ForegroundColor Green
$volume = New-DellScVolume -Connection $conn -StorageCenter $sc -Name $volumeName -Size 25Gb
if($volume -eq $null)
{
	Write-Host "Error creating Volume on the Storage Center" -ForegroundColor Red
	break
}

$server = Get-DellScServer -Connection $conn -StorageCenter $sc -Name $serverName
if($server -eq $null)
{
	Write-Host "Error Getting Server on Storage Center: $serverName" -ForegroundColor Red
	break
}

Write-Host "Map Volume [$volume] to Server [$server]" -ForegroundColor Green
$null = Add-DellScVolumeToServerMap -Connection $conn -Instance $volume -Server $server
if (!$?)
{
	Write-Host "Error Creating Mapping on Storage Center" -ForegroundColor Red
	break
}

# Deletes the Volume
$preferenceLevel = $confirmPreference
$confirmPreference = "None"

Write-Host "Delete Volume on the StorageCenter [Name: $volumeName]" -ForegroundColor Green
$null = Remove-DellScVolume -Connection $conn -Instance $volume
if (!$?)
{
	$confirmPreference = $preferenceLevel
	Write-Host "Error Deleting Volume on source Storage Center" -ForegroundColor Red
	break
}

$confirmPreference = $preferenceLevel