﻿ #******************************************************************************
 #*              Copyright 2014-2017 Dell Inc. or its subsidiaries.
 #*                           ALL RIGHTS RESERVED
 #*
 #*   THIS DOCUMENT OR ANY PART OF THIS DOCUMENT MAY NOT BE REPRODUCED WITHOUT
 #*   WRITTEN PERMISSION FROM DELL INC.
 #*
 #*   THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE RISK
 #*   OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
 #*
 #*   THIS CODE IS FOR DEMONSTRATION ONLY AND SHOULD NOT BE USED IN PRODUCTION ENVIRONMENTS 
 #*
 #******************************************************************************
#
# Script to create Replication
#
param
(
	[string] $sourceScSn = $(Read-Host -prompt "StorageCenterSourceSerialNumber"),
	[string] $destinationScSn = $(Read-Host -prompt "StorageCenterDestinationSerialNumber"),
	[bool] $cleanup = $TRUE,
    [string] $username = $(Read-Host -prompt "Data Collector Username"),
    [string] $password = $(Read-Host -prompt "Data Collector Password"),
    [string] $hostname = $(Read-Host -prompt "Data Collector Hostname"),
    [string] $port = $(Read-Host -prompt "Data Collector Port")
)

# Get the Connection to the Data Collector
$pass = ConvertTo-SecureString $password -AsPlainText -Force
$conn = Connect-DellApiConnection -Host $hostname -Port $port -User $username -password $pass
if($conn -eq $null)
{
    Write-Host "Error Connecting to the Data Collector" -ForegroundColor Red
    break
}


. .\ApiFunctions.ps1
if (!$?)
{
	Write-Host "Error Loading API Functions File" -ForegroundColor Red
	break
}

Write-Host "Start Create Replication Example [Source SN: $sourceScSn]  [Destination SN: $destinationScSn]"  -ForegroundColor Green

$sourceSc = Get-DellStorageCenter -Connection $conn -SerialNumber $sourceScSn
$destinationSc = Get-DellStorageCenter -Connection $conn -SerialNumber $destinationScSn

if($sourceSc -eq $null)
{
	Write-Host "Error Connecting to the Source Storage Center" -ForegroundColor Red
	break
}

if($destinationSc -eq $null)
{
	Write-Host "Error Connecting to the Destination Storage Center" -ForegroundColor Red
	break
}

Write-Host "Source Storage Center: $sourceSc" -ForegroundColor Green
Write-Host "Destination Storage Center: $destinationSc" -ForegroundColor Green

# Get a unique Volume Name
$volumeName = GetNextVolumeName $sourceSc $conn "CreateREplication1"

# Create a new Volume
Write-Host "Create New Volume on the Source [Name: $volumeName]" -ForegroundColor Green
$volume = New-DellScVolume -Connection $conn -StorageCenter $sourceSc -Name $volumeName -Size "5 GB"
if($volume -eq $null)
{
	Write-Host "Error Creating Volume on source Storage Center" -ForegroundColor Red
	break
}

# Gets the QoS Node
$qosList = Get-DellScReplicationQosNode -Connection $conn -StorageCenter $sourceSc
if($qosList -eq $null -or  $qosList.Count -eq 0)
{
	Write-Host "No QoS Nodes Found on Storage Center" -ForegroundColor Red
	break
}
if($qosList.Count -eq 1)
{
	$qos = $qosList
}
else
{
	$qos = $qosList[0]
}

Write-Host "Create the Replication [QoS: $qos]" -ForegroundColor Green
$replication = New-DellScReplication -Connection $conn -StorageCenter $sourceSc -DestinationStorageCenter $destinationSc -SourceVolume $volume -QosNode $qos
if($replication -eq $null)
{
	Write-Host "Error Creating Replication on source Storage Center" -ForegroundColor Red
	break
}

$destVolume = Get-DellScVolume -Connection $conn -InstanceId $replication.DestinationVolume.InstanceId
if($destVolume -eq $null)
{
	Write-Host "Error Getting the Destination Volume" -ForegroundColor Red
	break
}

if(!$cleanup)
{
	break
}

#Write-Host "Press any key to continue ..."
#$host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
Write-Host "Sleeping for 10 seconds ..."
Start-Sleep -s 10

# 
# Now Cleanup all the things created in the Example
#

$preferenceLevel = $confirmPreference
$confirmPreference = "None"

Write-Host "Abort the Replication [Name: $replication]" -ForegroundColor Green
Remove-DellScReplication -Connection $conn -Instance $replication
if (!$?)
{
	$confirmPreference = $preferenceLevel
	Write-Host "Error Aborting the Replication" -ForegroundColor Red
	break
}

Write-Host "Delete the Destination Volume [Name: $destVolume]" -ForegroundColor Green
Remove-DellScVolume -Connection $conn -Instance $destVolume
if (!$?)
{
	$confirmPreference = $preferenceLevel
	Write-Host "Error Deleting Volume on destination Storage Center" -ForegroundColor Red
	break
}

Write-Host "Delete the Source Volume [Name: $volumeName]" -ForegroundColor Green
Remove-DellScVolume -Connection $conn -Instance $volume
if (!$?)
{
	$confirmPreference = $preferenceLevel
	Write-Host "Error Deleting Volume on source Storage Center" -ForegroundColor Red
	break
}

$confirmPreference = $preferenceLevel

