﻿ #******************************************************************************
 #*              Copyright 2014-2017 Dell Inc. or its subsidiaries.
 #*                           ALL RIGHTS RESERVED
 #*
 #*   THIS DOCUMENT OR ANY PART OF THIS DOCUMENT MAY NOT BE REPRODUCED WITHOUT
 #*   WRITTEN PERMISSION FROM DELL INC.
 #*
 #*   THIS CODE IS MADE AVAILABLE AS IS, WITHOUT WARRANTY OF ANY KIND. THE ENTIRE RISK
 #*   OF THE USE OR THE RESULTS FROM THE USE OF THIS CODE REMAINS WITH THE USER.
 #*
 #*   THIS CODE IS FOR DEMONSTRATION ONLY AND SHOULD NOT BE USED IN PRODUCTION ENVIRONMENTS 
 #*
 #******************************************************************************
#
# Gets the next unique Volume name
#
function GetNextVolumeName
{
	param
	(
		$storageCenter = $(Throw "Storage Center connection is a required parameter"),
        $conn = $(Throw "Connection is a required parameter"),
		[string] $baseVolumeName = "GetNextVolumeNameViaPs"
	)
	
	[bool] $gotName = $FALSE
	$volumeName = $baseVolumeName
	$sourceVolumeList = Get-DellScVolume -StorageCenter $storageCenter -Connection $conn
	$count = 0
	while(!$gotName)
	{
		$gotName = $TRUE
		foreach($vol in $sourceVolumeList)
		{
			if($vol.Name -eq $volumeName)
			{
				$gotName = $FALSE
				break
			}
		}
		if($gotName)
		{
			break
		}
		$count += 1
		$volumeName = $baseVolumeName + " " + $count
	}
	return $volumeName
}